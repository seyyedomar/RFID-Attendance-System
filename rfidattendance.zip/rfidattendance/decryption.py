import rsa


def Decryption():
    private_key = open('private_key.key', 'rb')
    prikey = private_key.read()
    prkey = rsa.PrivateKey.load_pkcs1(prikey)

    # read the encrpted file
    encrypted_data = open("EncryptedFiles", "rb")
    edata = encrypted_data.read()

    # decrypt the data
    print(rsa.decrypt(edata, prkey).decode())


Decryption()
