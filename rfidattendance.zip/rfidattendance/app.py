import encryption
import decryption
import keygeneration


class App:
    @staticmethod
    def KeyGenaration():
        keygeneration.KeyGeneration()

    @staticmethod
    def DataEncrypt(message):
        encryption.Encryption(message)

    @staticmethod
    def DataDecrypt():
        decryption.Decryption()

# create Key


App.KeyGenaration()

# Encryption
message = input("Please enter thr Message")
App.DataEncrypt(message)

# decryption

App.DataEncrypt()
