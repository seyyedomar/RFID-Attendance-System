from cryptography.fernet import Fernet
import base64


def Encryption(message, key):
    key = key.encode("utf-8")
    key_base = key[:32].ljust(32, b'\x00')
    key_base64 = base64.urlsafe_b64encode(key_base)

    # create the cipher
    cipher = Fernet(key_base64)

    # encrypt the data
    encrypted_data = cipher.encrypt(bytes(message, 'utf-8'))
    edata = open("EncryptedFIles", "wb")
    edata.write(encrypted_data)


Encryption("Test Message ", "KeyTest")
